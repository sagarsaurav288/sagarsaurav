<?php include "connection.php" ?>

<?php

	if(isset($_POST['submit'])){
		$username = $_POST['txtname'];
		$password = $_POST['txtpass'];
		$email = $_POST['txtemail'];

		$query1 = "INSERT INTO student (user_name,user_pass,user_email)";
		$query1 .= "VALUES('{$username}','{$password}','{$email}')";

		$query2 = mysqli_query($connection,$query1);

		if(!$query2){
			die("Query Failed" . mysqli_error($connection));
		}
	}

?>