<?php 

require 'database.php'; 
  
 
echo 'ID'.' '.'Name'.' '.'User'.' '.'Pass'.'<br>'; 
  

$query = "SELECT * FROM `user_info`"; 

if ($is_query_run = mysql_query($query)) 
{ 
    
    while ($query_executed = mysql_fetch_assoc ($is_query_run)) 
    { 
       
        echo $query_executed['ID'].' '; 
        echo $query_executed['First Name'].' '; 
        echo $query_executed['Username'].' '; 
        echo $query_executed['Password'].'<br>'; 
    } 
} 
else
{ 
    echo "Error in execution"; 
} 
?> 