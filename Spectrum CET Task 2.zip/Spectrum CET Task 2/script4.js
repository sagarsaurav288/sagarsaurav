function present() {
  document.getElementById("label").innerHTML = "P";
}

function absent() {
  document.getElementById("label").innerHTML = "A";
}

function present1() {
  document.getElementById("label1").innerHTML = "P";
}

function absent1() {
  document.getElementById("label1").innerHTML = "A";
}

function present2() {
  document.getElementById("label2").innerHTML = "P";
}

function absent2() {
  document.getElementById("label2").innerHTML = "A";
}

function present3() {
  document.getElementById("label3").innerHTML = "P";
}

function absent3() {
  document.getElementById("label3").innerHTML = "A";
}

function present4() {
  document.getElementById("label4").innerHTML = "P";
}

function absent4() {
  document.getElementById("label4").innerHTML = "A";
}

function present5() {
  document.getElementById("label5").innerHTML = "P";
}

function absent5() {
  document.getElementById("label5").innerHTML = "A";
}

function present6() {
  document.getElementById("label6").innerHTML = "P";
}

function absent6() {
  document.getElementById("label6").innerHTML = "A";
}






