     setTimeout(function(){
		$(".loaderhome").fadeToggle();
	 },200);
	 
	 window.addEventListener("scroll", function(){
	 var header = document.querySelector("header");
	 header.classList.toggle("sticky", window.scrollY);
	
	})
	 function toggle(){
		 var header = document.querySelector("header");
		 header.classList.toggle("active");
	 }
	 
	 
	 $(document).ready(function(){
	
	$("#submit1").click(function(){
		$.ajax({
			url: "https://reqres.in/api/users",
			type: "POST",
			data: {
				  name: $("#name1").val()
			},
			success: function(response){
				console.log(response);
		    window.alert("Thank You" + " " + response.name);
		
		
	}
	
	
});	
});	
	
	
	
	});	